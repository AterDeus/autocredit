App = Ember.Application.create();

App.Router.map(function() {
  	this.resource('phone');
  	this.resource('smart');
  	this.resource('modem');
});



App.IndexRoute = Ember.Route.extend({
    model: function() {
        return phoneVars
    },
    beforeModel: function(sortByNetwork) {
      this.transitionTo('phone');
    },
    setupController: function(phone, phoneVars) {
      phone.set('model', phoneVars);
    }
});


App.ExpandController = Ember.ObjectController.extend({

    isExpanded: false,
    actions: {
        expandIt: function(isExpanded) {
            allControls = this.get('parentController');
            allControls = allControls.get('_subControllers');
            for (var i = allControls.length - 1; i >= 0; i--) {
                var everyObject = allControls[i];
                everyObject.set('isExpanded', false);
            };
            this.set('isExpanded', true);
        }
    }
})


App.PhoneRoute = Ember.Route.extend({
    model: function() {
        return phoneVars
    },
  	renderTemplate: function() {
      	this.render('phoneControls', {  
      	  into: 'application',                
      	  outlet: 'appControls'
      	}),
      	this.render('phone', {  
      	  into: 'application',                
      	  outlet: 'main',
          controller: 'phone'
      	}),
        this.render('phoneLength', {
            into: 'application',
            outlet: 'length',
            controller: 'phone'
        })
  	},
    setupController: function(phone, phoneVars) {
      phone.set('model', phoneVars);
    }
});

App.PhoneController = Ember.ArrayController.extend({
    queryParams: ['callTime','smsQuantity', 'network'],
    callTime: null,
    smsQuantity: null,
    network: 'inside',
    itemController: 'expand',
    actions: {
        sortByNetwork: function(model, callTime, smsQuantity, network, sortProperties) {
            var sortP = '',
                sortNet = '',
                sortCall = '',
                sortSms = '',
                minSMS = '',
                minMinutes = null,
                provider = '',
                callTime = this.get('callTime'),
                newModel = '',
                smsQuantity = this.get('smsQuantity'),
                network = this.get('network');
                onlyPhoneModel = phoneVars.filterBy('PROPERTY_PAY_ABON_FEDERAL_VALUE', '0');
                if (network == 'inside') {
                    provider = null;
                    sortNet = "PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE";
                }
                if (network == 'outside') {
                    provider = null;
                    sortNet = "PROPERTY_PRICE_MINUTE_RF_IN_OUTLIMIT1_VALUE"; 
                }
                if (network == 'mts') {
                    provider = 'МТС';
                    sortNet = "PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE";
                }
                if (network == 'megafon') {
                    provider = 'Мегафон';
                    sortNet = "PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE"; 
                }
                if (network == 'beeline') {
                    provider = 'Билайн';
                    sortNet = "PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE"; 
                };

                        if (callTime == '1') {
                            minMinutes = null;
                        }
                        if (callTime == '5') {
                            minMinutes = 100;
                        }
                        if (callTime == '10') {
                            minMinutes = 500;
                        };
                        if (smsQuantity == '50') {
                            minSMS = 50;
                        }
                        if (smsQuantity == '100') {
                            minSMS = 100;
                        }
                        if (smsQuantity == '200') {
                            minSMS = 200;
                        };

                        if (provider == null) {
                            this.set('model', onlyPhoneModel); 
                        }
                        else {
                            this.set('model', onlyPhoneModel); 
                            newModel = this.get('model').filterBy('PROPERTY_OPERATOR_VALUE', provider);
                            this.set('model', newModel);
                        };

                        if (minMinutes != null) {
                            var phoneModel = this.get('model');
                            var longCalls = this.filter(function(phoneModel) {
                                return phoneModel.PROPERTY_LIMIT_OUTGOING_MIN_VALUE >= minMinutes;
                            });
                            this.set('model', longCalls);
                        }
                        else {
                            if(newModel) { 
                            this.set('model', newModel);  
                            }
                            else {
                            this.set('model', onlyPhoneModel);         
                            };
                        };
                        if (minSMS != '') {
                            var smsModel = this.get('model');
                            var sortGo = sortNet;
                            var longSms = this.filter(function(smsModel) {
                                return smsModel.PROPERTY_LIMIT_OUTGOING_SMS_VALUE >= minSMS;
                            });
                            this.set('model', longSms);
                        };
                this.set('sortProperties', [sortNet]);

      }
    },
    endNumber: function(model) { 
        var endN = this.get('model');        
        endN = endN.get('length');
        return endN;
    }.property('model'),
    sortProperties: ['PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE"'],
    sortAscending: true,
});




App.SmartRoute = Ember.Route.extend({
	model: function() {
    return phoneVars;
	},
	renderTemplate: function() {
    	this.render('smartControls', {  
    	  into: 'application',                
    	  outlet: 'appControls'
    	}),
    	this.render('smart', {  
    	  into: 'application',                
    	  outlet: 'main'
    	}),
        this.render('phoneLength', {
            into: 'application',
            outlet: 'length',
            controller: 'smart'
        })
	},
    setupController: function(smart, phoneVars) {
      smart.set('model', phoneVars);
    }
});

App.SmartController = Ember.ArrayController.extend({
    queryParams: ['callTime','internetQuantity', 'network'],
    callTime: null,
    internetQuantity: null,
    network: 'inside',
    isExpanded: false,
    itemController: 'expand',
    actions: {
      sortByNetwork: function(model, callTime, internetQuantity, network, sortProperties) {
        var sortP = '',
            sortNet = '',
            sortCall = '',
            sortSms = '',
            minGB = '',
            minMinutes = '',
            provider = '',
            newModel = '',
            phoneModel = '',
            internetModel = '',
            callTime = this.get('callTime'),
            internetQuantity = this.get('internetQuantity'),
            network = this.get('network');
            this.set('model', phoneVars);
            var onlySmartModel = this.filter(function(){
                return phoneVars.PROPERTY_LIMIT_OUTGOING_TRAF_VALUE > 0;
            });
            this.set('model', onlySmartModel);
            console.log(this.get('model'));
                if (network == 'inside') {
                    provider = null;
                    sortNet = "PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE";
                }
                if (network == 'outside') {
                    provider = null;
                    sortNet = "PROPERTY_PRICE_MINUTE_RF_IN_OUTLIMIT1_VALUE"; 
                }
                if (network == 'mts') {
                    provider = 'МТС';
                    sortNet = "PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE";
                }
                if (network == 'megafon') {
                    provider = 'Мегафон';
                    sortNet = "PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE"; 
                }
                if (network == 'beeline') {
                    provider = 'Билайн';
                    sortNet = "PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE"; 
                };
                    if (callTime == '1') {
                        minMinutes = null;
                    }
                    if (callTime == '5') {
                        minMinutes = 100;
                    }
                    if (callTime == '10') {
                        minMinutes = 500;
                    };
                    if (internetQuantity == '0.5') {
                        minGB = 0.5;
                    }
                    if (internetQuantity == '1') {
                        minGB = 1;
                    }
                    if (internetQuantity == '2') {
                        minGB = 2;
                    };
                        if (provider != null && minMinutes != null && minGB != '') {
                            this.set('model', onlySmartModel); 
                            newModel = this.get('model').filterBy('PROPERTY_OPERATOR_VALUE', provider);
                            this.set('model', newModel);
                            var longCalls = this.filter(function(phoneModel) {
                                return phoneModel.PROPERTY_LIMIT_OUTGOING_MIN_VALUE >= minMinutes;
                            });
                            this.set('model', longCalls);
                            var longGB = this.filter(function(internetModel) {
                                return internetModel.PROPERTY_LIMIT_OUTGOING_TRAF_VALUE >= minGB;
                            });
                            this.set('model', longGB);
                        }
                        if (provider != null) {
                            this.set('model', onlySmartModel); 
                            newModel = this.get('model').filterBy('PROPERTY_OPERATOR_VALUE', provider);
                            this.set('model', newModel);
                        }
                        if (minMinutes != null) {
                            var phoneModel = this.get('model');
                            var longCalls = this.filter(function(phoneModel) {
                                return phoneModel.PROPERTY_LIMIT_OUTGOING_MIN_VALUE >= minMinutes;
                            });
                            this.set('model', longCalls);
                        }
                        if (minGB != '') {
                            var internetModel = this.get('model');
                            var longGB = this.filter(function(internetModel) {
                                return internetModel.PROPERTY_LIMIT_OUTGOING_TRAF_VALUE >= minGB;
                            });
                            this.set('model', longGB);
                        };
                        this.set('sortProperties', [sortNet]);

        },
        // expandIt: function(evt, isExpanded) {
        //     // allControls = this.get('parentController');
        //     // allControls = allControls.get('_subControllers');
        //     // for (var i = allControls.length - 1; i >= 0; i--) {
        //     //     var everyObject = allControls[i];
        //     //     everyObject.set('isExpanded', false);
        //     // };
        //     this.set('isExpanded', true);
        // }
    },
    endNumber: function(model) { 
        var endN = this.get('model');        
        endN = endN.get('length');
        return endN;
        console.log(endN)
    }.property('model'),
    sortProperties: ['PROPERTY_PRICE_MINUTE_INNET_OUTLIMIT1_VALUE'],
    sortAscending: false
});

////////////////////////////////////////////////////////////////MODEM////////////////////////////////////////////////////////////////


App.ModemRoute = Ember.Route.extend({
	model: function() {
    return phoneVars;
	},
	renderTemplate: function() {
    	this.render('modemControls', {  
    	  into: 'application',                
    	  outlet: 'appControls'
    	}),
    	this.render('modem', {  
    	  into: 'application',                
    	  outlet: 'main'
    	}),
        this.render('phoneLength', {
            into: 'application',
            outlet: 'length',
            controller: 'modem'
        })
	},
    setupController: function(modem, phoneVars) {
      modem.set('model', phoneVars);
    }
});

App.ModemController = Ember.ArrayController.extend({
    queryParams: ['deviceType','internetQuantity'],
    deviceType: 'stick',
    internetQuantity: null,
    itemController: 'expand',
    actions: {
      sortByNetwork: function(model, deviceType, internetQuantity, sortProperties) {
        var minGB = '',
            internetQuantity = this.get('internetQuantity'),
            deviceType = this.get('deviceType');
            this.set('model', phoneVars);
            var onlySmartModel = this.filter(function(phoneVars){
            return phoneVars.PROPERTY_LIMIT_OUTGOING_TRAF_VALUE > 0;
            });
            this.set('model', onlySmartModel);
                if (deviceType == 'stick') {
                    device = 'modem';
                }
                if (deviceType == 'pda') {
                    device = 'pda';
                }
                if (internetQuantity == '0.5') {
                    minGB = 0.5;
                }
                if (internetQuantity == '1') {
                    minGB = 1;
                }
                if (internetQuantity == '2') {
                    minGB = 2;
                };

                this.set('model', onlySmartModel); 
                // newModel = this.get('model').filterBy('PROPERTY_DEVICE_VALUE', device);
                // this.set('model', newModel);

                if (minGB != '') {
                    var internetModel = this.get('model');
                    var longGB = this.filter(function(internetModel) {
                        return internetModel.PROPERTY_LIMIT_OUTGOING_TRAF_VALUE >= minGB;
                    });
                    this.set('model', longGB);
                };

        },
        expandIt: function(isExpanded) {
            // allControls = this.get('parentController');
            // allControls = allControls.get('_subControllers');
            // for (var i = allControls.length - 1; i >= 0; i--) {
            //     var everyObject = allControls[i];
            //     everyObject.set('isExpanded', false);
            // };
            this.set('isExpanded', true);
        }
    },
    endNumber: function(model) { 
        var endN = this.get('model');        
        endN = endN.get('length');
        return endN;
    }.property('model'),
    sortProperties: ['PROPERTY_LIMIT_OUTGOING_TRAF_VALUE'],
    sortAscending: false,
});